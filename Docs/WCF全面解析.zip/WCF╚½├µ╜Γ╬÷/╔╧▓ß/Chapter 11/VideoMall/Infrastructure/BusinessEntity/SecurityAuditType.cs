﻿namespace Artech.VideoMall.Infrastructure.BusinessEntity
{
    public enum SecurityAuditType
    {
        AuthenticationSuccess,
        AuthenticationFailure,
        AuthorizationSuccess,
        AuthorizationFailure
    }
}
