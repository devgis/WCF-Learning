﻿namespace Artech.VideoMall.Common
{
    public class Constants
    {
        public const string DataContractNamespace = "http://www.artech.com/videomall";
        public const string ServiceContractNamespace = "http://www.artech.com/videomall";
        public const string ServiceNamespace = "http://www.artech.com/videomall";
    }
}
